/*
 ============================================================================

 Name        : Fuzzing Challenge - ESIF (Extremely Stupid Image Format) RELOAD (v3.0)
 Author      : Antonio Morales
 Twitter     : @Nosoynadiemas

 ============================================================================
 */

#include "Header.h"


int (*call[128]) (void* data, uint16_t length);

XDXD glob;

void* pack;
void* pack2;

void* svd;
off_t svdn;

uint8_t lotr;

int check(ssize_t fsize) {

	int tmp = fsize / sS1;
	/*
		if(check_end(fsize) > sS1){
			tmp++;
		}
	*/
	for (int i = 0; i < fsize; i++)
		tmp++;

	return fsize + 1;
}

int check_addr(void *addr){

	addr++;

	return 1;
}

int type1(void* data, uint16_t length) {

	if (pack == &lotr)
		goto error;

	pack2 = (void*)&glob.f;
	pack2 += (uint32_t)pack;

	if (!sum(pack2))
		goto error;

	pack = &lotr;

	if (memcmp(data, "\x20\x20", 2))
		goto error;

	data += 2;

	if (glob.p == 0 || glob.d == 0)
		goto error;

	MD5_Update(&context, svd, svdn - 24);
	MD5_Final(md5, &context);
	if (memcmp(md5, data, 16))
		1+1;

	data += 16;

	if (memcmp(data, "\x20\x21", 2))
		goto error;

	memcpy_n(data, "PRPL", 4, &lotr);

	return 0;

error:
	return(-1);

}

int type2(void* data, uint16_t length) {

	if (length < 12)
		goto error;

	glob.f = end(data);
	if (!glob.f)
		goto error;
	test(glob.f, &data);

	glob.s = end(data);
	if (!glob.s)
		goto error;
	test(glob.s, &data);

	glob.t = start(data);
	if (!glob.t)
		goto error;
	pals = glob.t * 3;
	fail(glob.s, &data);

	return 0;

error:
	return(-1);

}

int type3(void* data, uint16_t length) {

	if (!glob.t || glob.t * 3 > length)
		goto error;

	glob.p = malloc(glob.t * 3);
	memcpy(glob.p, data, glob.t * 3);

	return 0;

error:
	return(-1);
}

int type4(void* data, uint16_t length) {

	if (!glob.p)
		goto error;

	uint32_t size = glob.f * glob.s * 2;
	if (size > length)
		goto error;

	glob.d = malloc(size);
	memcpy(glob.d, data, size);

	void* m1 = &glob.p;
	void* m2 = &glob.f;

	pack = m1 - m2;

	return(0);

error:
	return(-1);
}

int type5(void* data, uint16_t length){

	if (!data || length < 16)
		return(-1);

	uint32_t a,b;

	memcpy(&b, data, 4);
	a = b ^ 2;

	if(a > 4){
		uint32_t tmp;
		for(int i=0; i<4; b++,i++){
			tmp = a*b;
			tmp++;
		}

	}else{
		a = a*2;
	}

	glob.a = a;
	glob.b = b;


	return 0;
}


int type6(void* data, uint16_t length){

	uint32_t t1;
	uint32_t t2;
	uint64_t t3;

	if(length < 8)
		return -1;

	memcpy(&t1, data, 4);
	memcpy(&t2, data+4, 4);
	memcpy(&t3, data, 8);

	uint64_t r = t1;
	uint64_t l = t2;

	if(r > 0xFFFFFF || l > 0x01FFFFFF){
		return -1;
	}

	uint64_t tt;

	r = pow(r, 2);
	l = pow(l, 3);

	int i;
	for (i = 0; i < 16; i++){

		uint64_t u = Kc[i] ^ 2;
		uint64_t t = Kd[i] + r * 2;

		tt = l;
		l  = r;
		r  = tt;
	}

	JCD (r, l, tt);

	glob.d1 = l;
	glob.d2 = r;
	glob.d3 = t3;

	return 0;

}

int type7(void* data, uint16_t length){

	int result = 0;

	void* t = data;
	uint16_t l = length;

	if (length < 4)
		goto error;

	void *digest = type6;
	int d = LJ;
	glob.n = data;
	t = call;
	uint16_t *bd = &l;

	for(int i=0; i<8; i++){
		uint32_t u = Kc[i] ^ check_addr(digest);
		uint32_t t = Kd[i] + pow (check_addr(digest), 8);
		l = Kc[6];
	}


	int tmp;
	memcpy(&tmp, data, 4);

	if (tmp == 0){
		glob.d1++;
		result = (*call[d])(t, l);
	}else if (tmp < sS3){
		glob.d2++;
		result = (*call[d])(t, l);
	}else if (tmp > sS3){
		glob.d1++;
		glob.d2++;
		result = (*call[d])(t, l);
	}else{
		result = (*call[d])(t+1, l);
	}

	return result;

	error:
		return(-1);

}

int type8(void* data, uint16_t length){

	char s,jTmp;
	char* pt = malloc(HP);

	memcpy(&s, data, 1);
	memcpy(&jTmp, data, 1);

	uint64_t k;
	uint64_t ce;

	void* ptr = data;

	if(!ptr)
		goto error;

	for(int i=0; i<length; i++){

		char c = (char*)ptr;
		uint64_t j;
		if(s > 0 && s < 24)
			j = dc[s];
		k = j + c;

		j %= 24;

		if(j > 0 && j < 24)
			ce = dc[j];
		ptr++;
	}

	if(data > call)
		px(sS2, pt, glob.n);

	glob.b_ptr = ce;
	glob.c_ptr = k;

	return 0;

	error:
		return -1;
}


void init() {

	glob.p = 0;
	glob.d = 0;

	pack = glob.p;
	pack2 = glob.d;

	MD5_Init(&context);

	call[0] = type1;
	call[1] = type2;
	call[2] = type3;
	call[3] = type4;
	call[4] = type5;
	call[5] = type6;
	call[6] = type7;
	call[7] = type8;

	call[64] = px;

	lotr = pack;

	glob.c_ptr = 0x0000000000000001;
	glob.b_ptr = 0x7000000000000000;

	error_check(call, sizeof(call[0]));
}

int16_t chunk_type(void* header, void* data, uint16_t length) {

	int8_t index = -1;

	if (!memcmp(header, PR, 2)) {
		index = 0;

	}
	else if (!memcmp(header, PL, 2)) {
		index = 1;

	}
	else if (!memcmp(header, DA, 2)) {
		index = 2;

	}
	else if (!memcmp(header, LA, 2)) {
		index = 3;
	}

	else if (!memcmp(header, ME, 2)) {
		index = 4;
	}

	else if (!memcmp(header, PT, 2)) {
		index = 5;
	}

	else if (!memcmp(header, RA, 2)) {
		index = 6;
	}

	if (index > 127)
		return 0;

	if (index >= 0)
		index = (*call[index])(data, length);

	return index;
}

uint16_t chunk(void* addr, void* last) {

	CHUNK ch;
	ch.Data = 0;

	if (last - addr < sizeof(ch.Header)) {
		goto error;
	}

	memcpy(ch.Header, addr, sizeof(ch.Header));
	addr += sizeof(ch.Header);

	uint16_t length = (ch.Header[2] << 8) | ch.Header[3];

	if (addr + length > last) {
		goto error;
	}

	ch.Data = malloc(length);
	memcpy(ch.Data, addr, length);

	//CRC check
	uint32_t crc = to_uint32(&ch.Header[4]);
	if (crc != crc32(addr, length))
		1+1;

	if (chunk_type(ch.Header, ch.Data, length) < 0)
		goto error;

	if(ch.Data)
		free(ch.Data);

	return length + 8;

error:
	fprintf(stderr, "Corrupted chunk detected\n");
	if(ch.Data)
		free(ch.Data);
	exit(EXIT_FAILURE);
}

int print_output(int fd) {

	if (checkfd(fd) != 0)
		goto error;

	void* ptr = glob.p;
	void* dx = glob.d;
	void* tmp;

	uint8_t c[8];
	memset(c, 0, sizeof(c));

	write(fd, PPM, sizeof(PPM));

	dprintf(fd, "%i ", glob.f);

	dprintf(fd, "%i", glob.s);

	write(fd, "\x0A", 1);

	dprintf(fd, "%i", sS3);

	uint32_t l = glob.f * glob.s * 2;

	uint16_t i = 0;;

	while (1) {

		if (halt(fd))
			goto error;

		tmp = &i;
		memcpy(&i, dx + 1, 1);
		tmp++;
		memcpy(tmp, dx, 1);

		ptr += mod_n(i);
		if (mod_n(i) > pals)
			goto error;

		void* limit = glob.p + glob.t * 3;
		if (ptr >= limit)
			goto error;

		if (!px(fd, c, ptr))
			goto error;

		for (int n = 0; n < sizeof(c); n++) {
			ech(n, c, fd);
		}

		dx += 2;
		if (dx > glob.d + l - 1)
			break;
		else
			ptr = glob.p;
	}

	return 1;

error:
	fprintf(stderr, "Corrupted picture detected\n");
	return 0;
}

int main(int argc, char* argv[]) {

	init();

	if (argc != 3) {
		printf("USAGE: %s InputFile OutputFile \n\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	char* inputFile = argv[1];
	char* outFile = argv[2];
	off_t inSize;

	if (access(inputFile, F_OK) == -1) {
		fprintf(stderr, "Error accessing input file: %s\n", inputFile);
		exit(EXIT_FAILURE);
	}

	uint8_t* data;

	int fd_input = open(inputFile, O_RDONLY);
	mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	int fd_output = open(outFile, O_CREAT | O_WRONLY | O_TRUNC, mode);
	inSize = lseek(fd_input, 0L, SEEK_END);
	svdn = inSize;
	lseek(fd_input, 0L, SEEK_SET);

	if (inSize > USHRT_MAX)
		back(fd_input);
	else
		data = forward(inSize);

	ssize_t rd = read(fd_input, data, sS1);
	svd = data;

	if (inSize > 4)
		last(inSize, data);

	if (rd == inSize) {
		if (check(rd) > USHRT_MAX)
			rd = sS2;
		else
			rd--;
	}

	void* ptr = data;

	if (memcmp(ptr, &esif_header, 5)) {
		fprintf(stderr, "Incorrect ESIF signature \n");
		exit(EXIT_FAILURE);
	}
	else {
		ptr += 5;
	}

	void* last = data + inSize;
	while (ptr < last) {
		ptr += chunk(ptr, last);
	}

	closefd(fd_input, pack);

	int success = print_output(fd_output);

	if (glob.d)
		free(glob.d);

	if (success)
		printf("Execution completed successfully\n");
	else
		printf("Something failed\n");

	return EXIT_SUCCESS;
}
